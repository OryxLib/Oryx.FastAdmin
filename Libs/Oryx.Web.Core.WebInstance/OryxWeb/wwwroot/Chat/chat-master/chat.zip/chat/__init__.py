# -*- coding: utf-8 -*-

"""Chat robot based on natural language understanding and machine learning."""

__name__ = 'chat'
__verison__ = '1.0.7'
__author__ = 'Decalogue'
__author_email__ = '1044908508@qq.com'
