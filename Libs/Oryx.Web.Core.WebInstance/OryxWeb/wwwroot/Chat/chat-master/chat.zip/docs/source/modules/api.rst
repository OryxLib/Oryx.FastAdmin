API - 语义理解 Restful API 接口
========================

.. image:: my_figs/api.png
  :scale: 50 %

.. automodule:: chat.api

.. autosummary::

   
   
语义理解 Restful API 接口
------------------------
.. autofunction:: 
