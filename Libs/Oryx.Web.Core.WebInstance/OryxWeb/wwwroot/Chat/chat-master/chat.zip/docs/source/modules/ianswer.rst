API - XML 封装答案
========================

.. image:: my_figs/ianswer.png
  :scale: 50 %

.. automodule:: chat.ianswer

.. autosummary::

   answer2xml
   
XML 封装答案
------------------------
.. autofunction:: answer2xml
