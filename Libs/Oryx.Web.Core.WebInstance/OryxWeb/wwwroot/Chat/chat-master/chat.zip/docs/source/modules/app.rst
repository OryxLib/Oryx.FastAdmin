API - 语义知识库管理 Flask app
========================

.. image:: my_figs/app.png
  :scale: 50 %

.. automodule:: chat.app

.. autosummary::

   app
   
Flask app
------------------------
.. autofunction:: app
