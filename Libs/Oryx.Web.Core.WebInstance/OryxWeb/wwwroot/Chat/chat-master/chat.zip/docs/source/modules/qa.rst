API - 语义理解问答
========================

.. image:: my_figs/qa.ico
  :scale: 50 %

.. automodule:: chat.qa

.. autosummary::

   Robot
   
语义理解机器人
------------------------
.. autofunction:: Robot
