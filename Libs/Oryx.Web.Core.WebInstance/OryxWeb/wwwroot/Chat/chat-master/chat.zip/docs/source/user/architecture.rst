.. _architecture:

======================
深入了解
======================

语义服务架构
==================

.. image:: my_figs/nlu_framework.png
  :scale: 100 %
  :align: center
  :target: https://github.com/decalogue/chat

子模块详细实现
==================

.. image:: my_figs/chat_modules.png
  :scale: 100 %
  :align: center
  :target: https://github.com/decalogue/chat

知识库
==================

.. image:: my_figs/database.png
  :scale: 30 %
  :align: center
  :target: https://github.com/decalogue/chat
