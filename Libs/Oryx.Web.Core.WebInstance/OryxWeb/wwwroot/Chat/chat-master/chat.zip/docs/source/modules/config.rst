API - chat 配置
========================

.. image:: my_figs/config.png
  :scale: 50 %

.. automodule:: chat.config

.. autosummary::

   config.getConfig
   
获取配置信息
------------------------
.. autofunction:: config.getConfig
