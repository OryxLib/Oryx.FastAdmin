API - 语义服务器
========================

.. image:: my_figs/server.ico
  :scale: 50 %

.. automodule:: chat.server

.. autosummary::

   MyTCPHandler
   start
   
创建语义服务器
------------------------
.. autofunction:: MyTCPHandler

启动语义服务器
------------------------
.. autofunction:: start