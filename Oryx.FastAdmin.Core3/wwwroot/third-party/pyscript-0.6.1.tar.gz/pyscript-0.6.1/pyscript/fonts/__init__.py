"""
Fonts module for PyScript
"""

__revision__ = '$Revision: 1.3 $'
